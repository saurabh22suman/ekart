import { Component, OnInit } from '@angular/core';
import * as data from 'src/assets/product.json';
import { Router } from "@angular/router";

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
})
export class HomeComponent implements OnInit {

  constructor(
    private router:Router
  ) { }

  ngOnInit(): void {
    console.log(data)
  }
  
  products:  any  = (data  as  any).default;
  headers=['title','type','price','rating']

  delete(i):void{
    console.log("Deleted "+i.toString());
    
  }

  update(i):void{
    var item=i;
    this.router.navigate(['/update'])
    
  }
}



import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {
  form: FormGroup;
  submitted:boolean=false;
  loading:boolean=false;
  constructor(
    private formBuilder: FormBuilder, private router:Router
  ) { }

  ngOnInit(): void {
    this.form = this.formBuilder.group({
      title: ['', Validators.required],
      type: ['', Validators.required],
      price:['',Validators.required]
  });
  }
  
  onSubmit() {
    this.submitted = true;
    if (this.form.invalid) {
      return;
    }
    console.log("Added");
    this.router.navigate(['/home'])
    

  this.loading = true;
  

}
get f() { return this.form.controls; }
}
